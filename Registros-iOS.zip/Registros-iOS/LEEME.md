# Registros 3.0 para iOS

Álbumes con carátulas personalizables y documentos continuos de texto, fotografías,
títulos y dibujos. Aplicación nativa en SwiftUI, UIKit y PencilKit. iOS 17+.

## GitHub

1. Sube Registros-iOS.zip a la raíz del repositorio.
2. Abre .github/workflows/build-ios.yml en GitHub y elige Editar.
3. Reemplaza su contenido con Compilar-Registros.txt y guarda.
4. Abre Actions → Compilar Registros iOS → Run workflow.
5. Descarga el artefacto Registros-iOS, extrae Registros.ipa e instálala con tu
   método de firma habitual.

El workflow también está dentro del ZIP. GitHub necesita el workflow como
archivo del repositorio para poder ejecutarlo. El ZIP tiene prioridad sobre
cualquier proyecto antiguo que permanezca descomprimido en el repositorio.
La IPA del workflow se genera sin firma y se firma al instalar.

## Álbumes

- El icono de álbum gris con + crea un álbum y abre su personalización.
- Puedes elegir nombre, imagen de carátula y color.
- Un toque abre el álbum. iOS 18+ usa la transición de ampliación de su carátula.
  iOS 17 utiliza la navegación nativa.
- Mantén pulsada una carátula para editarla o eliminar el álbum.
- La lupa busca nombres de álbum y textos de su contenido.
- El menú superior permite exportar e importar respaldos.

## Documento continuo

El álbum abre con su carátula y nombre, y el documento sigue hacia abajo.
Toca cualquier lugar en blanco para escribir un texto. Usa el menú + para crear
texto, un título, un subtítulo o añadir fotografías, y para elegir tipografía,
tamaño y tinta. Los títulos se añaden al índice al escribirlos.

Las fotografías se arrastran con un dedo. Usa dos para girarlas o pellizcar
su tamaño. Los textos también se pueden mover con dos dedos, girar y cambiar
de tamaño. El menú + puede eliminar el elemento seleccionado.

El lápiz abre la paleta nativa de PencilKit y permite dibujar con el dedo o Pencil.
Con dibujo activo, usa dos dedos para desplazar el documento. Toca de nuevo el
lápiz para volver a escribir. Los dibujos se guardan con el álbum.

El lienzo tiene anchura fija y aumenta su altura al avanzar hacia su final.
Las posiciones se guardan en coordenadas absolutas. Ampliar la altura y mostrar
el teclado conserva las posiciones de fotografías, textos y dibujos.

La barra flotante inferior muestra la sección actual. Tócala para abrir el
índice, y usa sus flechas para navegar entre títulos. Los títulos y subtítulos
se numeran por su orden vertical, y el índice se actualiza al escribir o moverlos.

## Datos anteriores

Se conserva pe.eduardo.carpetas como identificador de instalación para actualizar
la app previa con la misma identidad de firma. En el primer inicio, si encuentra
biblioteca.json de Librero, lo convierte a registros.json. Cada libro pasa a ser
un álbum y sus páginas forman un documento continuo. También se pueden importar
respaldos de Carpetas para Android y de Librero para iOS desde el menú.

La base anterior se conserva como fuente de la conversión. El respaldo de
Registros incluye carátulas, imágenes, texto, posición de los elementos y trazos.
Exporta un respaldo desde la app anterior antes de instalar si deseas tener
una copia independiente de tus datos.

## Verificación

El paquete se preparó en Linux. Se revisaron sintaxis Swift, estructura, recursos
y workflow. La compilación con los SDK de Apple y la prueba visual y de gestos
en iPhone quedan pendientes de ejecutar el workflow y abrir la aplicación.
