import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

@main
struct RegistrosApp: App {
    @StateObject private var store = RecordsStore()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            AlbumsView().environmentObject(store).preferredColorScheme(.light)
                .onChange(of: phase) { _, state in if state != .active { store.saveNow() } }
        }
    }
}

struct AlbumRoute: Hashable {
    var id: UUID
    var itemID: UUID? = nil
}
private struct AlbumSelection: Identifiable { let id: UUID }

struct Artwork: View {
    var album: RecordAlbum
    var body: some View {
        ZStack {
            Color(uiColor: UIColor(hex: album.tint))
            if let data = album.artwork, let image = UIImage(data: data) {
                GeometryReader { geometry in
                    Image(uiImage: image).resizable().scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                }
            } else {
                Image(systemName: "rectangle.stack.fill").resizable().scaledToFit()
                    .padding(50).foregroundStyle(.white.opacity(0.55))
            }
        }
        .aspectRatio(1, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 7))
    }
}

private struct AlbumSource: ViewModifier {
    var id: UUID
    var space: Namespace.ID
    func body(content: Content) -> some View {
        if #available(iOS 18.0, *) { content.matchedTransitionSource(id: id, in: space) }
        else { content }
    }
}
private struct AlbumTransition: ViewModifier {
    var id: UUID
    var space: Namespace.ID
    func body(content: Content) -> some View {
        if #available(iOS 18.0, *) { content.navigationTransition(.zoom(sourceID: id, in: space)) }
        else { content }
    }
}

struct AlbumsView: View {
    @EnvironmentObject private var store: RecordsStore
    @Namespace private var albumSpace
    @State private var path: [AlbumRoute] = []
    @State private var createAlbum = false
    @State private var editing: AlbumSelection?
    @State private var searching = false
    @State private var importing = false
    @State private var exporting = false
    @State private var backup = RecordsDocument(data: Data())
    @State private var restoreData: Data?
    @State private var confirmRestore = false
    @State private var removeAlbum: AlbumSelection?

    var body: some View {
        NavigationStack(path: $path) {
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 19), GridItem(.flexible(), spacing: 19)], alignment: .leading, spacing: 27) {
                    ForEach(store.albums) { album in
                        NavigationLink(value: AlbumRoute(id: album.id)) {
                            VStack(alignment: .leading, spacing: 9) {
                                Artwork(album: album).modifier(AlbumSource(id: album.id, space: albumSpace))
                                Text(album.title).font(.system(size: 16)).lineLimit(2).foregroundStyle(.primary)
                            }
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            Button("Editar carátula", systemImage: "photo") { editing = AlbumSelection(id: album.id) }
                            Button("Eliminar álbum", systemImage: "trash", role: .destructive) { removeAlbum = AlbumSelection(id: album.id) }
                        }
                    }
                }.padding(.horizontal, 22).padding(.top, 12).padding(.bottom, 30)
            }
            .navigationTitle("Registros")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Importar respaldo", systemImage: "square.and.arrow.down") { importing = true }
                        Button("Exportar registros", systemImage: "square.and.arrow.up") {
                            do { backup = RecordsDocument(data: try store.export()); exporting = true }
                            catch { store.error = error.localizedDescription }
                        }
                    } label: { Image(systemName: "ellipsis.circle").foregroundStyle(.secondary) }
                }
            }
            .safeAreaInset(edge: .bottom) {
                HStack {
                    Button { searching = true } label: {
                        Image(systemName: "magnifyingglass").font(.system(size: 24)).frame(width: 58, height: 52)
                    }.accessibilityLabel("Buscar registros")
                    Spacer()
                    Button { createAlbum = true } label: {
                        ZStack(alignment: .bottomTrailing) {
                            RoundedRectangle(cornerRadius: 7).fill(Color(uiColor: .systemGray5)).frame(width: 43, height: 43)
                            Image(systemName: "rectangle.stack").font(.system(size: 23)).foregroundStyle(.gray).frame(width: 43, height: 43)
                            Image(systemName: "plus.circle.fill").font(.system(size: 19))
                                .symbolRenderingMode(.palette).foregroundStyle(.gray, .white).offset(x: 6, y: 5)
                        }.frame(width: 58, height: 52)
                    }.accessibilityLabel("Crear álbum")
                }
                .foregroundStyle(.primary).padding(.horizontal, 25).padding(.vertical, 5)
                .background(.ultraThinMaterial).overlay(alignment: .top) { Divider().opacity(0.25) }
            }
            .navigationDestination(for: AlbumRoute.self) { route in
                AlbumEditor(albumID: route.id, initialItem: route.itemID)
                    .environmentObject(store)
                    .modifier(AlbumTransition(id: route.id, space: albumSpace))
            }
        }
        .tint(.primary)
        .sheet(isPresented: $createAlbum) {
            AlbumArtworkEditor(original: nil) { album in store.create(album) }
        }
        .sheet(item: $editing) { selection in
            if let album = store.album(selection.id) { AlbumArtworkEditor(original: album) { store.update($0, immediately: true) } }
        }
        .sheet(isPresented: $searching) {
            RecordsSearch { route in searching = false; path.append(route) }.environmentObject(store)
        }
        .confirmationDialog("¿Eliminar este álbum y su contenido?", isPresented: Binding(get: { removeAlbum != nil }, set: { if !$0 { removeAlbum = nil } }), titleVisibility: .visible) {
            Button("Eliminar álbum", role: .destructive) { if let selection = removeAlbum { store.remove(selection.id) }; removeAlbum = nil }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            do {
                let url = try result.get()
                let granted = url.startAccessingSecurityScopedResource()
                defer { if granted { url.stopAccessingSecurityScopedResource() } }
                restoreData = try Data(contentsOf: url); confirmRestore = true
            } catch { store.error = "No se pudo abrir el respaldo." }
        }
        .confirmationDialog("¿Restaurar este respaldo?", isPresented: $confirmRestore, titleVisibility: .visible) {
            Button("Restaurar", role: .destructive) {
                if let data = restoreData {
                    do { try store.restore(data) } catch { store.error = "El respaldo no es válido." }
                }
                restoreData = nil
            }
            Button("Cancelar", role: .cancel) { restoreData = nil }
        } message: { Text("El respaldo sustituirá los álbumes actuales.") }
        .fileExporter(isPresented: $exporting, document: backup, contentType: .json, defaultFilename: "Registros") { result in
            if case .failure(let error) = result { store.error = error.localizedDescription }
        }
        .alert("Registros", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("Aceptar") { store.error = nil }
        } message: { Text(store.error ?? "") }
    }
}

struct AlbumArtworkEditor: View {
    var original: RecordAlbum?
    var onSave: (RecordAlbum) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var draft = RecordAlbum()
    @State private var photo: PhotosPickerItem?
    @State private var loading = false
    @State private var photoError = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Artwork(album: draft).frame(maxWidth: 240).frame(maxWidth: .infinity).padding(.vertical, 15)
                        .listRowBackground(Color.clear)
                    PhotosPicker("Elegir carátula", selection: $photo, matching: .images)
                    if draft.artwork != nil { Button("Quitar imagen") { draft.artwork = nil } }
                }
                Section {
                    TextField("Nombre del álbum", text: $draft.title)
                    ColorPicker("Color de carátula", selection: Binding(get: { Color(uiColor: UIColor(hex: draft.tint)) },
                                                                      set: { draft.tint = UIColor($0).hex }), supportsOpacity: false)
                }
            }
            .navigationTitle(original == nil ? "Nuevo álbum" : "Carátula").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") { draft.title = draft.title.trimmingCharacters(in: .whitespacesAndNewlines); onSave(draft); dismiss() }
                        .disabled(loading || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear { if let original { draft = original } }
            .onChange(of: photo) { _, item in
                guard let item else { return }
                loading = true
                Task { @MainActor in
                    defer { loading = false }
                    do {
                        guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadUnknown) }
                        draft.artwork = try RecordsStore.photo(data)
                    } catch { photoError = true }
                }
            }
            .alert("No se pudo cargar la carátula.", isPresented: $photoError) { Button("Aceptar", role: .cancel) {} }
        }
    }
}

struct RecordsSearch: View {
    var open: (AlbumRoute) -> Void
    @EnvironmentObject private var store: RecordsStore
    @State private var query = ""
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.albums.filter { album in
                    query.isEmpty || album.title.localizedStandardContains(query) || album.items.contains { $0.text.localizedStandardContains(query) }
                }) { album in
                    Section {
                        Button { open(AlbumRoute(id: album.id)) } label: {
                            HStack(spacing: 13) {
                                Artwork(album: album).frame(width: 48, height: 48)
                                Text(album.title).foregroundStyle(.primary)
                            }
                        }
                        if !query.isEmpty {
                            ForEach(album.items.filter { !$0.text.isEmpty && $0.text.localizedStandardContains(query) }.prefix(12)) { item in
                                Button { open(AlbumRoute(id: album.id, itemID: item.id)) } label: {
                                    Text(item.text).lineLimit(3).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
            }
            .searchable(text: $query, prompt: "Álbumes y contenido")
            .navigationTitle("Buscar").navigationBarTitleDisplayMode(.large)
        }
    }
}
