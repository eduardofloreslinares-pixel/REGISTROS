import SwiftUI
import UIKit
import PencilKit

struct CanvasRequest: Equatable {
    var id = UUID()
    var operation = ""
    var image: Data?
    var itemID: UUID?
    var font = "Georgia"
    var size = 38.0
    var ink = "#202020"
}

struct RecordCanvas: UIViewControllerRepresentable {
    var album: RecordAlbum
    var request: CanvasRequest
    var drawing: Bool
    var onSave: (RecordAlbum, Bool) -> Void
    var onSection: (UUID?) -> Void
    func makeUIViewController(context: Context) -> RecordCanvasController {
        let controller = RecordCanvasController()
        controller.configure(self)
        return controller
    }
    func updateUIViewController(_ controller: RecordCanvasController, context: Context) { controller.configure(self) }
}

@MainActor
final class RecordCanvasController: UIViewController, UITextViewDelegate, PKCanvasViewDelegate, UIGestureRecognizerDelegate {
    private let scroll = UIScrollView()
    private let root = UIView()
    private let paper = UIView()
    private let header = UIView()
    private let artwork = UIImageView()
    private let artworkSymbol = UIImageView(image: UIImage(systemName: "rectangle.stack"))
    private let titleLabel = UILabel()
    private let drawingCanvas = PKCanvasView()
    private let toolPicker = PKToolPicker()
    private var settings: RecordCanvas?
    private var record = RecordAlbum()
    private var fields: [UUID: UITextView] = [:]
    private var pictures: [UUID: UIImageView] = [:]
    private var selected: UUID?
    private var lastRequest: UUID?
    private var currentSection: UUID?
    private var factor: CGFloat = 0.5
    private var measuredWidth: CGFloat = 0
    private var updating = false
    private var viewportBottom: CGFloat = 0
    private var drawMode = false
    private var saveDrawing: Task<Void, Never>?
    private let pageWidth: CGFloat = 760
    private let headerHeight: CGFloat = 620

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        scroll.frame = view.bounds
        scroll.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scroll.delegate = self
        scroll.contentInsetAdjustmentBehavior = .never
        scroll.keyboardDismissMode = .interactive
        scroll.alwaysBounceVertical = true
        scroll.showsHorizontalScrollIndicator = false
        scroll.showsVerticalScrollIndicator = false
        scroll.backgroundColor = .white
        scroll.addSubview(root)
        view.addSubview(scroll)
        root.layer.anchorPoint = .zero
        root.layer.position = CGPoint(x: 12, y: 0)
        root.backgroundColor = .white
        root.addSubview(header)
        root.addSubview(paper)
        paper.backgroundColor = .white
        artwork.clipsToBounds = true
        artwork.layer.cornerRadius = 12
        artwork.contentMode = .scaleAspectFill
        header.addSubview(artwork)
        artworkSymbol.contentMode = .scaleAspectFit
        artworkSymbol.tintColor = UIColor.white.withAlphaComponent(0.7)
        artwork.addSubview(artworkSymbol)
        titleLabel.font = .systemFont(ofSize: 54, weight: .bold)
        titleLabel.textAlignment = .center
        titleLabel.numberOfLines = 2
        titleLabel.textColor = .label
        header.addSubview(titleLabel)
        drawingCanvas.isOpaque = false
        drawingCanvas.backgroundColor = .clear
        drawingCanvas.isScrollEnabled = false
        drawingCanvas.drawingPolicy = .anyInput
        drawingCanvas.delegate = self
        drawingCanvas.isUserInteractionEnabled = false
        toolPicker.addObserver(drawingCanvas)
        paper.addSubview(drawingCanvas)
        let tap = UITapGestureRecognizer(target: self, action: #selector(blankTap(_:)))
        tap.delegate = self
        paper.addGestureRecognizer(tap)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboard(_:)),
                                                name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(flush),
                                                name: UIApplication.willResignActiveNotification, object: nil)
    }
    deinit {
        saveDrawing?.cancel()
        NotificationCenter.default.removeObserver(self)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        flush()
        toolPicker.setVisible(false, forFirstResponder: drawingCanvas)
    }
    func configure(_ value: RecordCanvas) {
        loadViewIfNeeded()
        let first = settings == nil
        settings = value
        if first { record = value.album }
        else {
            // Keep in-flight text and gestures authoritative until their delegate commits them.
            var incoming = value.album
            for local in record.items {
                if fields[local.id]?.isFirstResponder == true || isTransforming(local.id) {
                    if let index = incoming.items.firstIndex(where: { $0.id == local.id }) { incoming.items[index] = local }
                }
            }
            if !drawingCanvas.isFirstResponder { record = incoming }
            else {
                incoming.drawing = record.drawing
                record = incoming
            }
        }
        render()
        setDrawing(value.drawing)
        if lastRequest != value.request.id {
            lastRequest = value.request.id
            let request = value.request
            DispatchQueue.main.async { [weak self] in self?.execute(request) }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if abs(measuredWidth - scroll.bounds.width) > 1 {
            measuredWidth = scroll.bounds.width
            factor = max(0.2, (scroll.bounds.width - 24) / pageWidth)
            root.transform = CGAffineTransform(scaleX: factor, y: factor)
            root.layer.position = CGPoint(x: 12, y: 0)
            layoutCanvas()
        }
    }

    private func layoutCanvas() {
        let wasUpdating = updating
        updating = true
        defer { updating = wasUpdating }
        let height = max(1600, record.canvasHeight)
        // Anchor zero keeps existing content stationary when this height grows.
        root.bounds = CGRect(x: 0, y: 0, width: pageWidth, height: headerHeight + height)
        header.frame = CGRect(x: 0, y: 0, width: pageWidth, height: headerHeight)
        artwork.frame = CGRect(x: 180, y: 36, width: 400, height: 400)
        artworkSymbol.frame = CGRect(x: 120, y: 120, width: 160, height: 160)
        titleLabel.frame = CGRect(x: 48, y: 468, width: 664, height: 125)
        paper.frame = CGRect(x: 0, y: headerHeight, width: pageWidth, height: height)
        drawingCanvas.frame = paper.bounds
        drawingCanvas.contentSize = paper.bounds.size
        scroll.contentSize = CGSize(width: scroll.bounds.width, height: (headerHeight + height) * factor + 50)
        scroll.contentInset.bottom = viewportBottom + 100
    }

    private func render() {
        updating = true
        defer { updating = false }
        titleLabel.text = record.title
        artwork.backgroundColor = UIColor(hex: record.tint)
        if let image = record.artwork { artwork.image = UIImage(data: image); artworkSymbol.isHidden = true }
        else { artwork.image = nil; artworkSymbol.isHidden = false }
        layoutCanvas()
        if !drawingCanvas.isFirstResponder {
            let drawing = record.drawing.flatMap { try? PKDrawing(data: $0) } ?? PKDrawing()
            if drawing.dataRepresentation() != drawingCanvas.drawing.dataRepresentation() { drawingCanvas.drawing = drawing }
        }
        let ids = Set(record.items.map(\.id))
        for id in Array(fields.keys) where !ids.contains(id) { fields.removeValue(forKey: id)?.removeFromSuperview() }
        for id in Array(pictures.keys) where !ids.contains(id) { pictures.removeValue(forKey: id)?.removeFromSuperview() }
        for item in record.items {
            if item.kind == "image" {
                let imageView: UIImageView
                if let existing = pictures[item.id] { imageView = existing }
                else {
                    imageView = UIImageView(image: item.image.flatMap { UIImage(data: $0) })
                    imageView.contentMode = .scaleAspectFit
                    imageView.isUserInteractionEnabled = true
                    imageView.accessibilityIdentifier = item.id.uuidString
                    pictures[item.id] = imageView
                    paper.addSubview(imageView)
                    addGestures(to: imageView, text: false)
                    let tap = UITapGestureRecognizer(target: self, action: #selector(selectPicture(_:)))
                    imageView.addGestureRecognizer(tap)
                }
                place(imageView, item: item)
            } else {
                let field: UITextView
                if let existing = fields[item.id] { field = existing }
                else {
                    field = UITextView()
                    field.backgroundColor = .clear
                    field.textContainerInset = .zero
                    field.textContainer.lineFragmentPadding = 0
                    field.isScrollEnabled = false
                    field.delegate = self
                    field.accessibilityIdentifier = item.id.uuidString
                    field.accessibilityLabel = item.heading > 0 ? "Título de sección" : "Texto"
                    fields[item.id] = field
                    paper.addSubview(field)
                    addGestures(to: field, text: true)
                }
                if !field.isFirstResponder { field.text = item.text }
                field.font = font(item)
                field.textColor = UIColor(hex: item.ink)
                field.textAlignment = item.heading > 0 ? .center : .left
                place(field, item: item)
            }
        }
        for (id, field) in fields {
            if let index = record.items.firstIndex(where: { $0.id == id }) { record.items[index].height = field.bounds.height }
        }
        let bottom = record.items.map { $0.y + $0.height }.max() ?? 0
        if bottom + 700 > record.canvasHeight {
            record.canvasHeight = ceil((bottom + 700) / 1200) * 1200
            layoutCanvas()
        }
        if drawMode { paper.bringSubviewToFront(drawingCanvas) }
        else { paper.sendSubviewToBack(drawingCanvas) }
    }

    private func font(_ item: CanvasItem) -> UIFont {
        UIFont(name: item.font, size: item.fontSize) ?? .systemFont(ofSize: item.fontSize, weight: item.heading > 0 ? .medium : .regular)
    }
    private func place(_ object: UIView, item: CanvasItem) {
        object.transform = .identity
        var height = item.height
        if let field = object as? UITextView {
            height = max(60, field.sizeThatFits(CGSize(width: item.width, height: 10000000)).height)
        }
        object.bounds = CGRect(x: 0, y: 0, width: item.width, height: height)
        object.center = CGPoint(x: item.x + item.width / 2, y: item.y + height / 2)
        object.transform = CGAffineTransform(rotationAngle: item.rotation * .pi / 180)
    }
    private func setDrawing(_ enabled: Bool) {
        guard drawMode != enabled else { return }
        drawMode = enabled
        scroll.panGestureRecognizer.minimumNumberOfTouches = enabled ? 2 : 1
        drawingCanvas.isUserInteractionEnabled = enabled
        if enabled {
            view.endEditing(true)
            paper.bringSubviewToFront(drawingCanvas)
            drawingCanvas.tool = PKInkingTool(.pencil, color: .black, width: 4)
            drawingCanvas.becomeFirstResponder()
            toolPicker.setVisible(true, forFirstResponder: drawingCanvas)
        } else {
            drawingCanvas.resignFirstResponder()
            toolPicker.setVisible(false, forFirstResponder: drawingCanvas)
            paper.sendSubviewToBack(drawingCanvas)
            DispatchQueue.main.async { [weak self] in self?.commit() }
        }
    }

    private func visibleY() -> Double {
        max(80, Double(scroll.contentOffset.y / factor - headerHeight + 140))
    }
    private func addText(at point: CGPoint, heading: Int = 0) {
        var item = CanvasItem()
        item.x = heading > 0 ? 60 : min(540, max(30, point.x))
        item.y = max(24, point.y)
        item.width = heading > 0 ? 640 : min(640, 730 - item.x)
        item.heading = heading
        item.font = heading > 0 ? "HelveticaNeue" : settings?.request.font ?? "Georgia"
        item.fontSize = heading == 1 ? 76 : heading == 2 ? 58 : settings?.request.size ?? 38
        item.ink = settings?.request.ink ?? "#202020"
        record.items.append(item)
        selected = item.id
        grow(to: item.y + 500)
        render()
        commit()
        fields[item.id]?.becomeFirstResponder()
    }

    private func execute(_ request: CanvasRequest) {
        switch request.operation {
        case "text", "h1", "h2":
            addText(at: CGPoint(x: 60, y: visibleY()), heading: request.operation == "h1" ? 1 : request.operation == "h2" ? 2 : 0)
        case "photo":
            guard let data = request.image, let image = UIImage(data: data) else { return }
            view.endEditing(true)
            var item = CanvasItem()
            item.kind = "image"; item.image = data; item.x = 120; item.y = visibleY() + 30
            item.width = 520; item.height = max(20, 520 * image.size.height / max(1, image.size.width))
            record.items.append(item); selected = item.id
            grow(to: item.y + item.height + 600)
            render(); commit()
        case "jump":
            if let id = request.itemID, let item = record.items.first(where: { $0.id == id }) {
                view.endEditing(true)
                scroll.setContentOffset(CGPoint(x: 0, y: max(0, (headerHeight + item.y) * factor - 20)), animated: true)
            }
        case "font":
            if let id = selected, let index = record.items.firstIndex(where: { $0.id == id && $0.kind == "text" }) {
                var item = record.items[index]
                item.font = request.font; item.fontSize = request.size; item.ink = request.ink
                record.items[index] = item
                render(); commit()
            }
        case "delete":
            if let id = selected {
                record.items.removeAll { $0.id == id }
                selected = nil; render(); commit()
            }
        default: break
        }
    }

    private func grow(to height: Double) {
        if height > record.canvasHeight { record.canvasHeight = ceil(height / 1200) * 1200; layoutCanvas() }
    }
    private func commit(immediate: Bool = false) { if !updating { settings?.onSave(record, immediate) } }
    @objc private func flush() {
        if drawMode { record.drawing = drawingCanvas.drawing.dataRepresentation() }
        commit(immediate: true)
    }

    @objc private func blankTap(_ gesture: UITapGestureRecognizer) {
        guard !drawMode else { return }
        addText(at: gesture.location(in: paper))
    }
    @objc private func selectPicture(_ gesture: UITapGestureRecognizer) {
        view.endEditing(true)
        selected = gesture.view?.accessibilityIdentifier.flatMap(UUID.init(uuidString:))
        for (id, picture) in pictures {
            picture.layer.borderWidth = id == selected ? 1 : 0
            picture.layer.borderColor = UIColor.systemGray3.cgColor
        }
    }
    private func addGestures(to object: UIView, text: Bool) {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(move(_:)))
        pan.minimumNumberOfTouches = text ? 2 : 1
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(resize(_:)))
        let rotate = UIRotationGestureRecognizer(target: self, action: #selector(rotate(_:)))
        for gesture in [pan, pinch, rotate] {
            gesture.delegate = self
            object.addGestureRecognizer(gesture)
        }
        scroll.panGestureRecognizer.require(toFail: pan)
    }
    private func isTransforming(_ id: UUID) -> Bool {
        let object: UIView? = fields[id].map { $0 as UIView } ?? pictures[id].map { $0 as UIView }
        return (object?.gestureRecognizers ?? []).contains { $0.state == .began || $0.state == .changed }
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if gestureRecognizer.view !== paper { return !drawMode }
        var ancestor: UIView? = touch.view
        while let object = ancestor, object !== paper {
            if object is UITextView || object is UIImageView { return false }
            ancestor = object.superview
        }
        return !drawMode
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        gestureRecognizer.view === otherGestureRecognizer.view
    }

    @objc private func move(_ gesture: UIPanGestureRecognizer) {
        guard let object = gesture.view, let id = object.accessibilityIdentifier.flatMap(UUID.init(uuidString:)),
              let index = record.items.firstIndex(where: { $0.id == id }) else { return }
        selected = id
        var item = record.items[index]
        let delta = gesture.translation(in: paper)
        item.x = min(760 - item.width, max(0, item.x + delta.x))
        item.y = max(0, item.y + delta.y)
        record.items[index] = item
        gesture.setTranslation(.zero, in: paper)
        grow(to: item.y + item.height + 800)
        place(object, item: item)
        let point = gesture.location(in: view)
        if point.y > view.bounds.height - 90 {
            scroll.contentOffset.y += 6
        } else if point.y < 90 { scroll.contentOffset.y = max(0, scroll.contentOffset.y - 6) }
        if gesture.state == .ended || gesture.state == .cancelled { commit() }
    }
    @objc private func rotate(_ gesture: UIRotationGestureRecognizer) {
        guard let object = gesture.view, let id = object.accessibilityIdentifier.flatMap(UUID.init(uuidString:)),
              let index = record.items.firstIndex(where: { $0.id == id }) else { return }
        selected = id
        var item = record.items[index]
        item.rotation = (item.rotation + gesture.rotation * 180 / .pi).truncatingRemainder(dividingBy: 360)
        record.items[index] = item
        gesture.rotation = 0
        place(object, item: item)
        if gesture.state == .ended || gesture.state == .cancelled { commit() }
    }
    @objc private func resize(_ gesture: UIPinchGestureRecognizer) {
        guard let object = gesture.view, let id = object.accessibilityIdentifier.flatMap(UUID.init(uuidString:)),
              let index = record.items.firstIndex(where: { $0.id == id }) else { return }
        selected = id
        var item = record.items[index]
        if item.kind == "image" {
            let width = min(720, max(100, item.width * gesture.scale))
            item.height = max(20, item.height * width / item.width)
            item.width = width
            item.x = min(item.x, 760 - width)
        } else { item.fontSize = min(120, max(16, item.fontSize * gesture.scale)) }
        gesture.scale = 1
        record.items[index] = item
        grow(to: item.y + item.height + 800)
        place(object, item: item)
        if gesture.state == .ended || gesture.state == .cancelled { commit() }
    }
    func textViewDidBeginEditing(_ textView: UITextView) { selected = textView.accessibilityIdentifier.flatMap(UUID.init(uuidString:)) }
    func textViewDidChange(_ textView: UITextView) {
        guard let id = textView.accessibilityIdentifier.flatMap(UUID.init(uuidString:)),
              let index = record.items.firstIndex(where: { $0.id == id }) else { return }
        var item = record.items[index]
        item.text = textView.text
        item.height = max(60, textView.sizeThatFits(CGSize(width: item.width, height: 10000000)).height)
        record.items[index] = item
        place(textView, item: item)
        grow(to: item.y + item.height + 800)
        commit()
    }

    func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
        guard !updating else { return }
        record.drawing = canvasView.drawing.dataRepresentation()
        saveDrawing?.cancel()
        saveDrawing = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .milliseconds(180)) } catch { return }
            self?.commit()
        }
    }
    func canvasViewDidEndUsingTool(_ canvasView: PKCanvasView) { commit() }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard settings != nil, !updating, measuredWidth > 0 else { return }
        let y = max(0, Double(scroll.contentOffset.y / factor - headerHeight))
        let section = record.headings.last(where: { $0.y <= y + 100 })?.id
        if section != currentSection {
            currentSection = section
            let callback = settings?.onSection
            DispatchQueue.main.async { callback?(section) }
        }
        if scroll.contentOffset.y + scroll.bounds.height > scroll.contentSize.height - 450 * factor {
            record.canvasHeight += 1200
            layoutCanvas()
            commit()
        }
    }
    @objc private func keyboard(_ notification: Notification) {
        guard let frame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        viewportBottom = max(0, view.bounds.maxY - view.convert(frame, from: nil).minY)
        scroll.contentInset.bottom = viewportBottom + 100
        if let field = fields.values.first(where: { $0.isFirstResponder }), let selection = field.selectedTextRange {
            let rect = field.convert(field.caretRect(for: selection.end), to: scroll)
            scroll.scrollRectToVisible(rect.insetBy(dx: -20, dy: -32), animated: true)
        }
    }
}
