import SwiftUI
import PhotosUI

struct AlbumEditor: View {
    let albumID: UUID
    var initialItem: UUID? = nil
    @EnvironmentObject private var store: RecordsStore
    @State private var request = CanvasRequest()
    @State private var drawing = false
    @State private var sectionID: UUID?
    @State private var showIndex = false
    @State private var editArtwork = false
    @State private var choosePhoto = false
    @State private var photo: PhotosPickerItem?
    @State private var loadingPhoto = false
    private var album: RecordAlbum? { store.album(albumID) }
    private var entries: [HeadingEntry] { album?.headings ?? [] }
    private var sectionIndex: Int? { entries.firstIndex { $0.id == sectionID } }

    var body: some View {
        Group {
            if let album {
                RecordCanvas(album: album, request: request, drawing: drawing,
                             onSave: { store.update($0, immediately: $1) },
                             onSection: { sectionID = $0 })
                    .ignoresSafeArea(.keyboard)
                    .safeAreaInset(edge: .bottom, spacing: 0) { bottomBar }
            }
        }
        .background(.white)
        .ignoresSafeArea(.keyboard)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) { Text(album?.title ?? "").font(.subheadline.weight(.semibold)).lineLimit(1) }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("Editar carátula", systemImage: "photo") { editArtwork = true }
                    Button("Ir al inicio", systemImage: "arrow.up.to.line") {
                        if let first = entries.first { jump(first.id) }
                    }.disabled(entries.isEmpty)
                } label: { Image(systemName: "ellipsis") }
            }
        }
        .sheet(isPresented: $showIndex) { indexSheet }
        .sheet(isPresented: $editArtwork) {
            if let album { AlbumArtworkEditor(original: album) { store.update($0, immediately: true) } }
        }
        .photosPicker(isPresented: $choosePhoto, selection: $photo, matching: .images)
        .onChange(of: photo) { _, item in loadPhoto(item) }
        .onAppear {
            if let initialItem { jump(initialItem) }
        }
        .onDisappear { store.saveNow() }
    }

    private var bottomBar: some View {
        HStack(spacing: 10) {
            Button { previousSection() } label: {
                Image(systemName: "chevron.left").font(.system(size: 17, weight: .medium)).frame(width: 30, height: 40)
            }.disabled(entries.isEmpty || (sectionIndex ?? -1) < 1)
                .accessibilityLabel("Sección anterior")
            Button { showIndex = true } label: {
                HStack(spacing: 9) {
                    Image(systemName: "line.3.horizontal").foregroundStyle(.secondary)
                    Text(currentHeading).font(.system(size: 15)).lineLimit(1).frame(maxWidth: .infinity, alignment: .leading)
                }.frame(height: 40)
            }.accessibilityLabel("Abrir índice")
            Button { nextSection() } label: {
                Image(systemName: "chevron.right").font(.system(size: 17, weight: .medium)).frame(width: 30, height: 40)
            }.disabled(entries.isEmpty || (sectionIndex ?? -1) >= entries.count - 1)
                .accessibilityLabel("Sección siguiente")
            Rectangle().fill(.quaternary).frame(width: 1, height: 24)
            Button { drawing.toggle() } label: {
                Image(systemName: drawing ? "pencil.tip.crop.circle.fill" : "pencil.tip.crop.circle").font(.system(size: 20)).frame(width: 27, height: 40)
            }.accessibilityLabel(drawing ? "Volver a escribir" : "Dibujar")
            Menu {
                Button("Texto", systemImage: "text.alignleft") { send("text") }
                Button("Título", systemImage: "textformat.size.larger") { send("h1") }
                Button("Subtítulo", systemImage: "textformat.size.smaller") { send("h2") }
                Button("Fotografía", systemImage: "photo") { choosePhoto = true }
                Divider()
                Menu("Tipografía") {
                    ForEach(["Georgia", "HelveticaNeue", "Baskerville", "Menlo", "Noteworthy"], id: \.self) { font in
                        Button(font) { request.font = font; send("font") }
                    }
                    Divider()
                    Button("Pequeña") { request.size = 30; send("font") }
                    Button("Mediana") { request.size = 38; send("font") }
                    Button("Grande") { request.size = 54; send("font") }
                    ColorPicker("Tinta", selection: Binding(get: { Color(uiColor: UIColor(hex: request.ink)) },
                                                           set: { request.ink = UIColor($0).hex; send("font") }), supportsOpacity: false)
                }
                Button("Eliminar selección", systemImage: "trash", role: .destructive) { send("delete") }
            } label: {
                Image(systemName: loadingPhoto ? "hourglass" : "plus").font(.system(size: 19)).frame(width: 27, height: 40)
            }.accessibilityLabel("Añadir contenido")
        }
        .foregroundStyle(.primary)
        .padding(.horizontal, 13).padding(.vertical, 5)
        .background(.regularMaterial, in: Capsule())
        .overlay { Capsule().stroke(.quaternary, lineWidth: 0.5) }
        .shadow(color: .black.opacity(0.07), radius: 12, y: 5)
        .padding(.horizontal, 14).padding(.bottom, 8).padding(.top, 5)
    }

    private var currentHeading: String {
        if let index = sectionIndex, entries.indices.contains(index) {
            return entries[index].number + "  " + entries[index].text.replacingOccurrences(of: "\n", with: " ")
        }
        return "Índice"
    }
    private var indexSheet: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    if entries.isEmpty {
                        Text("Los títulos que escribas aparecerán aquí.").foregroundStyle(.secondary).padding(.vertical, 24)
                    }
                    ForEach(entries) { entry in
                        Button {
                            showIndex = false
                            jump(entry.id)
                        } label: {
                            HStack(alignment: .firstTextBaseline, spacing: 12) {
                                Text(entry.number).foregroundStyle(.secondary).frame(width: 35, alignment: .trailing)
                                Text(entry.text).foregroundStyle(entry.id == sectionID ? Color.primary : Color.secondary)
                                    .font(.system(size: entry.level == 1 ? 18 : 17, weight: entry.level == 1 ? .medium : .regular))
                                Spacer(minLength: 0)
                            }
                            .padding(.leading, entry.level == 2 ? 15 : 0).padding(.vertical, 11)
                        }.buttonStyle(.plain)
                    }
                }.padding(.horizontal, 25).padding(.bottom, 35)
            }
            .navigationTitle("Índice").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { showIndex = false } } }
        }.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }

    private func send(_ operation: String) {
        drawing = false
        request.operation = operation
        request.id = UUID()
    }
    private func jump(_ id: UUID) {
        request.itemID = id
        send("jump")
    }
    private func previousSection() {
        guard let index = sectionIndex, index > 0 else { return }
        jump(entries[index - 1].id)
    }
    private func nextSection() {
        let next = (sectionIndex ?? -1) + 1
        guard entries.indices.contains(next) else { return }
        jump(entries[next].id)
    }
    private func loadPhoto(_ item: PhotosPickerItem?) {
        guard let item else { return }
        loadingPhoto = true
        Task { @MainActor in
            defer { loadingPhoto = false; photo = nil }
            do {
                guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadUnknown) }
                request.image = try RecordsStore.photo(data)
                send("photo")
            } catch { store.error = "No se pudo cargar la fotografía." }
        }
    }
}
