import SwiftUI
import UIKit
import PencilKit
import UniformTypeIdentifiers

struct CanvasItem: Codable, Equatable, Identifiable {
    var id = UUID()
    var kind = "text"
    var text = ""
    var image: Data?
    var x = 60.0
    var y = 80.0
    var width = 640.0
    var height = 72.0
    var rotation = 0.0
    var heading = 0
    var font = "Georgia"
    var fontSize = 38.0
    var ink = "#202020"
}

struct RecordAlbum: Codable, Equatable, Identifiable {
    var id = UUID()
    var title = "Nuevo álbum"
    var artwork: Data?
    var tint = "#B6B6BB"
    var items: [CanvasItem] = []
    var drawing: Data?
    var canvasHeight = 1600.0
    var updated = Date()
}

struct RecordsArchive: Codable {
    var version = 1
    var albums: [RecordAlbum] = []
}

struct HeadingEntry: Identifiable, Equatable {
    let id: UUID
    let text: String
    let number: String
    let level: Int
    let y: Double
}

extension RecordAlbum {
    var headings: [HeadingEntry] {
        let sorted = items.filter { $0.kind == "text" && $0.heading > 0 && !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted {
                if $0.y != $1.y { return $0.y < $1.y }
                if $0.x != $1.x { return $0.x < $1.x }
                return $0.id.uuidString < $1.id.uuidString
            }
        var major = 0, minor = 0
        return sorted.map { item in
            if item.heading == 1 { major += 1; minor = 0 }
            else {
                if major == 0 { major = 1 }
                minor += 1
            }
            return HeadingEntry(id: item.id, text: item.text, number: item.heading == 1 ? "\(major)" : "\(major).\(minor)",
                                level: item.heading, y: item.y)
        }
    }
}

extension UIColor {
    convenience init(hex: String) {
        let n = UInt32(hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted), radix: 16) ?? 0x202020
        self.init(red: CGFloat((n >> 16) & 255) / 255, green: CGFloat((n >> 8) & 255) / 255, blue: CGFloat(n & 255) / 255, alpha: 1)
    }
    var hex: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

struct RecordsDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        self.data = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

@MainActor
final class RecordsStore: ObservableObject {
    @Published private(set) var albums: [RecordAlbum] = []
    @Published var error: String?
    private var canWrite = true
    private var pending: Task<Void, Never>?
    private let url = URL.documentsDirectory.appending(path: "registros.json")

    init() {
        do {
            if FileManager.default.fileExists(atPath: url.path) {
                albums = try Self.decode(Data(contentsOf: url)).albums
            } else {
                let legacy = URL.documentsDirectory.appending(path: "biblioteca.json")
                if FileManager.default.fileExists(atPath: legacy.path) {
                    albums = try LegacyImport.albums(Data(contentsOf: legacy))
                    saveNow()
                }
            }
        } catch {
            canWrite = false
            self.error = "No se pudo abrir el archivo guardado. Puedes restaurar un respaldo desde el menú."
        }
    }
    func album(_ id: UUID) -> RecordAlbum? { albums.first { $0.id == id } }
    func create(_ album: RecordAlbum) {
        albums.append(album)
        saveNow()
    }
    func update(_ album: RecordAlbum, immediately: Bool = false) {
        guard let index = albums.firstIndex(where: { $0.id == album.id }) else { return }
        var changed = album
        changed.updated = Date()
        albums[index] = changed
        if immediately { saveNow() }
        else {
            pending?.cancel()
            pending = Task { @MainActor [weak self] in
                do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                self?.saveNow()
            }
        }
    }
    func remove(_ id: UUID) {
        albums.removeAll { $0.id == id }
        saveNow()
    }
    func saveNow() {
        pending?.cancel()
        guard canWrite else { error = "Restaura un respaldo antes de guardar nuevos cambios."; return }
        do { try export().write(to: url, options: .atomic) }
        catch { self.error = "No se pudo guardar. \(error.localizedDescription)" }
    }
    func export() throws -> Data { try JSONEncoder().encode(RecordsArchive(albums: albums)) }
    func restore(_ data: Data) throws {
        let next: [RecordAlbum]
        if let native = try? Self.decode(data) { next = native.albums }
        else { next = try LegacyImport.albums(data) }
        albums = next
        canWrite = true
        saveNow()
    }
    private static func decode(_ data: Data) throws -> RecordsArchive {
        let archive = try JSONDecoder().decode(RecordsArchive.self, from: data)
        guard archive.version == 1, Set(archive.albums.map(\.id)).count == archive.albums.count else { throw CocoaError(.fileReadCorruptFile) }
        for album in archive.albums {
            guard album.canvasHeight.isFinite, album.canvasHeight >= 1200,
                  Set(album.items.map(\.id)).count == album.items.count else { throw CocoaError(.fileReadCorruptFile) }
            for item in album.items {
                guard ["text", "image"].contains(item.kind), item.x.isFinite, item.y.isFinite,
                      (0...760).contains(item.x), item.y >= 0,
                      (40...760).contains(item.width), item.height.isFinite && item.height >= 20,
                      item.rotation.isFinite, (0...2).contains(item.heading), (16...120).contains(item.fontSize) else {
                    throw CocoaError(.fileReadCorruptFile)
                }
            }
        }
        return archive
    }

    static func photo(_ data: Data) throws -> Data {
        guard let image = UIImage(data: data) else { throw CocoaError(.fileReadCorruptFile) }
        let ratio = min(1, 1800 / max(image.size.width, image.size.height))
        let size = CGSize(width: image.size.width * ratio, height: image.size.height * ratio)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let result = UIGraphicsImageRenderer(size: size, format: format).image { _ in image.draw(in: CGRect(origin: .zero, size: size)) }
        guard let jpeg = result.jpegData(compressionQuality: 0.88) else { throw CocoaError(.fileReadCorruptFile) }
        return jpeg
    }
}

enum LegacyImport {
    static func albums(_ data: Data) throws -> [RecordAlbum] {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw CocoaError(.fileReadCorruptFile) }
        if let books = root["books"] as? [[String: Any]] { return books.map(book) }
        guard let folders = root["folders"] as? [[String: Any]], let entries = root["entries"] as? [[String: Any]] else {
            throw CocoaError(.fileReadCorruptFile)
        }
        return folders.map { folder in
            var album = RecordAlbum()
            album.title = folder["name"] as? String ?? "Álbum"
            let id = folder["id"] as? String ?? ""
            let pages = entries.filter { ($0["folder"] as? String) == id }
            addPages(pages, to: &album)
            return album
        }
    }
    private static func book(_ value: [String: Any]) -> RecordAlbum {
        var album = RecordAlbum()
        if let id = value["id"] as? String, let uuid = UUID(uuidString: id) { album.id = uuid }
        album.title = value["title"] as? String ?? "Álbum"
        album.tint = value["color"] as? String ?? "#B6B6BB"
        if let photo = value["coverPhoto"] as? String { album.artwork = Data(base64Encoded: photo) }
        addPages(value["pages"] as? [[String: Any]] ?? [], to: &album)
        return album
    }
    private static func addPages(_ pages: [[String: Any]], to album: inout RecordAlbum) {
        var base = 80.0
        var strokes: [PKStroke] = []
        for page in pages {
            if let fragments = page["fragments"] as? [[String: Any]] {
                for old in fragments {
                    var item = CanvasItem()
                    item.text = old["text"] as? String ?? ""
                    item.x = (old["x"] as? Double ?? 0.12) * 760
                    item.y = base + (old["y"] as? Double ?? 0.12) * 1000
                    item.width = max(80, min(700, (old["width"] as? Double ?? 0.68) * 760))
                    item.font = old["font"] as? String ?? "Georgia"
                    item.fontSize = max(16, min(120, (old["size"] as? Double ?? 32) * 760 / 700))
                    item.rotation = old["rotation"] as? Double ?? 0
                    item.ink = old["color"] as? String ?? "#202020"
                    if let title = page["title"] as? String, !title.isEmpty, item.text == title {
                        item.heading = 1
                    }
                    album.items.append(item)
                }
            } else {
                let title = page["title"] as? String ?? ""
                if !title.isEmpty {
                    var item = CanvasItem()
                    item.heading = 1; item.text = title; item.y = base; item.font = "HelveticaNeue"; item.fontSize = 66; item.height = 100
                    album.items.append(item)
                }
                let text = page["text"] as? String ?? page["body"] as? String ?? ""
                if !text.isEmpty {
                    var item = CanvasItem()
                    item.text = text; item.y = base + 140; item.height = max(120, Double(text.count) * 0.9)
                    album.items.append(item)
                }
            }
            let objects = page["objects"] as? [[String: Any]] ?? page["images"] as? [[String: Any]] ?? []
            for (index, old) in objects.enumerated() {
                let encoded = old["image"] as? String ?? (old["src"] as? String)?.components(separatedBy: ",").last
                guard let encoded, let bytes = Data(base64Encoded: encoded), let image = UIImage(data: bytes) else { continue }
                var item = CanvasItem()
                item.kind = "image"; item.image = bytes
                item.width = max(100, min(680, (old["width"] as? Double ?? 0.45) * 760))
                item.height = max(20, item.width * image.size.height / max(1, image.size.width))
                item.x = max(20, min(740 - item.width, (old["x"] as? Double ?? 0.5) * 760 - item.width / 2))
                item.y = max(base, base + (old["y"] as? Double ?? (0.5 + Double(index) * 0.2)) * 1000 - item.height / 2)
                item.rotation = old["rotation"] as? Double ?? 0
                album.items.append(item)
            }
            if let drawing = page["drawing"] as? String, let bytes = Data(base64Encoded: drawing), let old = try? PKDrawing(data: bytes) {
                let converted = old.transformed(by: CGAffineTransform(translationX: 0, y: base).scaledBy(x: 760 / 700, y: 1))
                strokes.append(contentsOf: converted.strokes)
            }
            base = max(base + 1400, (album.items.map { $0.y + $0.height }.max() ?? base) + 160)
        }
        album.canvasHeight = max(1600, base + 900)
        if !strokes.isEmpty { album.drawing = PKDrawing(strokes: strokes).dataRepresentation() }
    }
}
